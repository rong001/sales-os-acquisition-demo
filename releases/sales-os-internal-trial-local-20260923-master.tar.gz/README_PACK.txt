Sales OS internal trial pack — sales-os-internal-trial-local-20260923-master
Git tip included in tree: 654b56bde9668cb0e0a19fd85b8d28b630d37584
See START_WINDOWS.md (Docker path A + native path B) and START_INTERNAL.md.
Evidence: sales-os-app/docs/acceptance/internal-trial/SALES-MASTER-20260923/
