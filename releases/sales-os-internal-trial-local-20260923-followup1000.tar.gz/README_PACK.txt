Sales OS internal trial pack — sales-os-internal-trial-local-20260923-followup1000
Git tip included in tree: 1ab9b3d37b87c3e4b0e91a9bb0fce5840490e7dc
Short: 1ab9b3d
See START_WINDOWS.md (Docker path A + native path B) and START_INTERNAL.md.
Evidence: sales-os-app/docs/acceptance/internal-trial/SALES-FOLLOWUP-20260923-1000/
Parent pack: sales-os-internal-trial-local-20260923-master (SHA256 46fe4844…0fac)
Windows native PASS: NOT claimed — retest on user PC required.
