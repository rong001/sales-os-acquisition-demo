SALES-FOLLOWUP-20260923-1331 trial pack
Unpack over existing sales-os-app tree. KEEP .env.native and .data/.
Prefer overlay of CHANGED files — see sales-os-app/docs/acceptance/internal-trial/SALES-FOLLOWUP-20260923-1331/DIFF-OVERLAY.md
Also: sales-os-internal-trial-local-20260923-followup1331-overlay.tar.gz (changed files only).
Rebuild after overlay (dist is gitignored):
  npm run build -w @sales-os/api
  npm run build -w @sales-os/worker
  npm run build -w @sales-os/web
Windows native:
  .\scripts\windows\native\Start-InternalTrial-Native.ps1
  .\scripts\windows\native\Test-InternalTrial-Native.ps1
  .\scripts\windows\native\Invoke-BusinessAcceptance.ps1
product_green=NO while UI SKIP. See UI-PENDING.md
